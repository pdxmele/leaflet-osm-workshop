leaflet-osm-workshop
================

Example web map code & slides for a Leaflet/OSM workshop I'm helping to lead at GIS in Action 2013 (and have co-led in the past at NACIS 2012)

Presentation slides at http://pdxmele.com/leaflet-osm-workshop/slides.pdf

HTML & JS versions ready to start tutorial with, built from code by Wm Leler at http://pdxmele.com/leaflet-osm-workshop/osmLeaf.html

Completed exercise version (DON'T PEEK!!): http://pdxmele.com/leaflet-osm-workshop/complete/osmLeaf.html

Includes dists of [Leaflet](https://github.com/leaflet) and [jQuery](http://jquery.com/), the use of which is subject to their own licenses.
